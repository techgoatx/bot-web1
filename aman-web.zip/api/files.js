const axios = require('axios');

module.exports = async (req, res) => {
    try {
        const repo = process.env.GITHUB_REPO;
        const token = process.env.GITHUB_TOKEN;
        const filePath = req.query.path || '';

        if (!repo) {
            return res.status(400).json({ success: false, error: 'GITHUB_REPO not set' });
        }

        const headers = { 'User-Agent': 'AMAN-MD' };
        if (token) headers['Authorization'] = `token ${token}`;

        const url = `https://api.github.com/repos/${repo}/contents/${filePath}`;
        const response = await axios.get(url, { headers });

        let files = response.data;
        if (!Array.isArray(files)) files = [files];

        const fileList = files.map(f => ({
            name: f.name,
            path: f.path,
            size: f.size ? (f.size / 1024).toFixed(2) + ' KB' : '',
            download_url: f.download_url || f.url,
            type: f.type
        }));

        res.status(200).json({ success: true, files: fileList });
    } catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
};
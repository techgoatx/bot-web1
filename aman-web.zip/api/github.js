const axios = require('axios');

module.exports = async (req, res) => {
    try {
        const repo = process.env.GITHUB_REPO;
        const token = process.env.GITHUB_TOKEN;

        if (!repo) {
            return res.status(400).json({ success: false, error: 'GITHUB_REPO not set' });
        }

        const headers = { 'User-Agent': 'AMAN-MD' };
        if (token) headers['Authorization'] = `token ${token}`;

        const url = `https://api.github.com/repos/${repo}/contents/`;
        const response = await axios.get(url, { headers });

        res.status(200).json({ success: true, files: response.data });
    } catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
};
const crypto = require('crypto');

const PASSWORD = process.env.WEBSITE_PASSWORD || 'fuckedbyaman';

module.exports = async (req, res) => {
    if (req.method !== 'POST') {
        return res.status(405).json({ success: false, error: 'Method not allowed' });
    }

    try {
        const { password } = req.body;
        if (!password) {
            return res.status(400).json({ success: false, error: 'Password required' });
        }

        if (password === PASSWORD) {
            const token = crypto.randomBytes(32).toString('hex');
            return res.status(200).json({ success: true, token });
        } else {
            return res.status(401).json({ success: false, error: 'Wrong password' });
        }
    } catch (err) {
        return res.status(500).json({ success: false, error: err.message });
    }
};